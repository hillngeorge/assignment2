// Salon information object
let salon = {
    name: "Fashion Pet",
    phone: "999-999-9999",
    address: {
        street: "palm st",
        number: "1642",
        zip: "89102"
    },
    pets: []
}

// Constructor
class Pet {
    constructor(n, a, g, b, s, t) {
        this.name = n;
        this.age = a;
        this.gender = g;
        this.breed = b;
        this.service = s;
        this.type = t;
    }
}

// DOM elements
const info = document.getElementById("info");

// Function to display salon information in the footer
function displayFooterInfo(){
    document.getElementById("info").innerHTML = `
        <p>Welcome to the ${salon.name}, located at ${salon.address.street} ${salon.address.number} ${salon.address.zip}</p>
    `;
}

// Initialize function
function init() {
    let Pet1 = new Pet("scooby", 60, "Male", "Hound", "Grooming", "Dog");
    let Pet2 = new Pet("scrappy", 50, "Male", "Hound", "Grooming", "Dog");
    let Pet3 = new Pet("tiny", 40, "Male", "Hound", "Grooming", "Dog");
    salon.pets.push(Pet1, Pet2, Pet3);
    displayFooterInfo();
}

// Call the init function when the window is fully loaded
window.onload = init;

// Event listener to register a new pet
document.addEventListener('DOMContentLoaded', function (){
    let inputName = document.getElementById("txtName");
    let inputAge = document.getElementById("txtAge");
    let inputGender = document.getElementById("txtGender");
    let inputBreed = document.getElementById("txtBreed");
    let inputService = document.getElementById("txtService");
    let inputType = document.getElementById("txtType");

    function register(event){
        event.preventDefault();
        let newPet = new Pet(inputName.value, inputAge.value, inputGender.value, inputBreed.value, inputService.value, inputType.value);
        salon.pets.push(newPet);
        displayFooterInfo();
        event.target.reset(); // Reset the form
    }

    document.getElementById("petForm").addEventListener("submit", register);
});
