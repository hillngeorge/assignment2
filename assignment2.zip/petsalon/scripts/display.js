
function displayPetNames() {
    let petList = document.getElementById('pets');
    petList.innerHTML = "petList";
    salon.pets.forEach(pet => {
        petList.innerHTML += `<p>${pet.name}</p>`;
    });
    document.getElementById('totalPets').innerHTML = `Total: ${salon.pets.length}`;

}


function displayPetCards(){
    getE('pets').innerHTML="";
    let card="";
    for(let i=0;i<salon.pets.length;i++){
        let pet = salon.pets[i];
        card+=`
        <div class="petcard">
        <p>Name: ${pet.name}</p>
        <p>Name: ${pet.age}</p>
        <p>Name: ${pet.gender}</p>
        <p>Name: ${pet.breed}</p>
        <p>Name: ${pet.service}</p>
        <p>Name: ${pet.type}</p>
        
        </div>`;
}
getE('pets').innerHTML=card;
}